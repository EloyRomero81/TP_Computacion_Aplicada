#!/bin/bash

#Declaracion de variables
hora=$(date "+%H:%M:%S")
dia=$(date "+%Y%m%d")
directorio_origen="$1"
directorio_destino="$2"

#Función para registrar eventos en el log
log(){
   echo "$dia - $hora - $1|$2" >> /var/log/backup_full.log
}

#Funcion para enviar el log por correo (usando mutt)
enviar_log(){
   mutt -s "Log de respaldo" root < /var/log/backup_full.log
}

#Función para realizar respaldo
hacer_backup(){
   nombre_backup="$(basename "$directorio_origen")_bkp_$dia.tar.gz"

   if [ -d "$directorio_origen" ] || ! mountpoint -q "$directorio_origen"; then
      tar -czf "$directorio_destino/$nombre_backup" -C "$directorio_origen"  .
      log "Respaldo de $directorio_origen" "Éxito"
   else
      log "Directorio $directorio_origen no encontrado o no está montado" "Error"
   fi
}

#Opción de ayuda
while getopts "h" option; do
   case $option in
      h)
         echo "Forma de uso: $0 directorio_origen directorio_destino"
         exit
         ;;
      \?)
         echo "Opcion no válida: -$OPTARG" 
         exit 1
         ;;
   esac
done

if [ "$#" -ne 2 ]; then
   echo "Forma de uso: $0 directorio_origen directorio_destino"
   exit 1
fi

#Verifica si el directorio destino existe y está montado
if [ ! -d "$directorio_destino" ] || ! mountpoint -q "$directorio_destino"; then
   log "El directorio de destino $directorio_destino no existe o no está montado"
   enviar_log
   exit 1
fi

#Realiza los respaldos
hacer_backup "$directorio_origen" "$directorio_destino"

#Envia log por correo al usuario root
enviar_log   

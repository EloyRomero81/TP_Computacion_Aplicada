#!/bin/bash

# Comprobar si el proceso dado como arumento está en ejecucíon
if pgrep -x "$1" >/dev/null; then
   echo "El proceso $1 está en ejecución."
else
   # Enviar un correo al usuario root
   echo "El proceso $1 no se está ejecutando. Enviando correo al root..."
   echo "El proceso $1 no se está ejecutando actualmente." | mail -s "Alerta de proceso no ene ejcución" root
fi
